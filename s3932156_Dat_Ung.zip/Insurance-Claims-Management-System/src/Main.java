import Data.LoadDataToList;
/**
 * @author <Ung Xuan Dat - s3932156>
 */
public class Main {
    public static void main(String[] args) {
        MenuSystem.menu();
    }
}