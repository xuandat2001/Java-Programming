package Claim;
/**
 * @author <Ung Xuan Dat - s3932156>
 */
public enum Status {
    NEW,
    PROCESSING,
    DONE

}
